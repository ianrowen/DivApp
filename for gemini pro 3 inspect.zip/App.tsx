// App.tsx
/**
 * Divin8 App Entry Point
 * * CRITICAL: This file handles:
 * - AI provider initialization
 * - Authentication state management
 * - Navigation setup
 */

import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View, StyleSheet, StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import * as WebBrowser from 'expo-web-browser'; // Required for auth flows

// Core
import AIProvider from './src/core/api/aiProvider';
import { geminiProvider } from './src/core/api/gemini';
import { supabase } from './src/core/api/supabase';
import type { User } from '@supabase/supabase-js';

// Screens
import HomeScreen from './src/screens/HomeScreen';
import LoginScreen from './src/features/auth/screens/LoginScreen';

const Stack = createStackNavigator();

// CRITICAL: Tell Expo's WebBrowser to check for and finish any pending auth flows.
// This is the most stable method for handling OAuth and Magic Link redirects.
WebBrowser.maybeCompleteAuthSession();

export default function App() {
  const [isReady, setIsReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    initializeApp();
  }, []);

  async function initializeApp() {
    try {
      // 1. Register AI providers
      AIProvider.register('gemini', geminiProvider);
      AIProvider.setProvider('gemini');
      console.log('✅ AI provider initialized');

      // 2. Check initial authentication state (Supabase persistence)
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);
      console.log('✅ Auth state loaded:', session?.user ? 'User logged in' : 'No user');

      // 3. Listen for auth changes
      const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
        // This listener automatically updates when tokens arrive from the deep link redirect
        setUser(session?.user ?? null);
      });

      setIsReady(true);

      // Cleanup subscription on unmount
      return () => {
        subscription?.unsubscribe();
      };
    } catch (error) {
      console.error('❌ App initialization failed:', error);
      setIsReady(true);
    }
  }

  if (!isReady) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  return (
    <>
      <StatusBar barStyle="dark-content" />
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          {user ? (
            // Authenticated routes
            <>
              <Stack.Screen name="Home" component={HomeScreen} />
              {/* Add more authenticated screens here */}
            </>
          ) : (
            // Unauthenticated routes
            <Stack.Screen name="Login" component={LoginScreen} />
          )}
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
  },
});